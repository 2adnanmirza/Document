module "lamdba" {
  source = "./Terraform-AWS-Lambda"
  bucket_name = "sanjana-demo"
  runtime = "python3.9"
  s3_key = "example.zip"
  rolename = "lambda_role"
  handler = "test-funtion"
  function_name = "demo-2"
}