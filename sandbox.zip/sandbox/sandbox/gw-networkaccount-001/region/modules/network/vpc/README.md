provider "aws" {
    }

locals {
common = {
  ou_name  = "sbx"
  bu_name  = "telecomm"
  env      = "01"
  function = "app"
}

}
module "sbx" {
source = "../../modules/network/vpc"
vpc_enabled = true
region = "us-east-1"
cidr_block = "10.0.0.0/16"
common = local.common

}